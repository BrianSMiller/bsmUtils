% DEMO_TWOSCALE_BIODUCK  Pulse-rate and unit-rate estimation on a real
% bioduck recording, using prrTwoScale.m.
%
% Terminology: pulse (single downsweep) -> unit (sub-train of pulses) ->
% call (the full sequence).
%
% Validated result on 2716_CallType_1A.wav (176 s):
%   pulse rate: ACF 2.632 Hz, Welch 5.469 Hz (2:1 harmonic, ACF correct)
%   unit rate:  ACF 6.60 s (2:1 harmonic), Welch 3.20 s (Welch correct,
%               matches Dreo et al. 2025's published AMW ICI range of
%               2.7-3.3 s)
%
% NOT included here: the real spectrogram-based cepstral method (Dreo et
% al. 2025 / cepstroBSM.m). Tested separately in Python
% (prr_analysis.cepstrum_via_spectrogram) with sp-equivalent parameters at
% both scales, and it does NOT show usable comb structure at either scale
% on this file: the averaged magnitude spectrum is essentially flat near
% both expected spacings (2.64 Hz and 0.31 Hz), on both linear and dB
% scales. Working hypothesis: bioduck pulses are wideband downsweep
% chirps, not the narrowband tone bursts the cepstral comb-detection
% method (and Patris et al.'s Model A) assumes; ordinary biological pulse-
% to-pulse variability in sweep shape is enough to wash out any comb when
% magnitude spectra are averaged across ~460 pulse instances, even though
% the pulses' TIMING is extremely regular (which is why ACF/Welch on the
% envelope work well: they don't care what happens spectrally within each
% pulse). If you want to see this directly in MATLAB, build two sp rows
% (in the style of getBioduckShortParams.m: Fmin=50, Fmax=250, NewFS=400,
% fft=1024 for pulse scale / fft=8000 for unit scale, overlap=0.75) and
% run cepstroBSM.m on this file with each -- expect the same flat result
% unless something differs between implementations, in which case that
% itself is worth knowing.
%
% Requires on path: prrAutocorr.m, prrWelch.m, prrTwoScale.m,
% envelopeExtract.m, checkTonal.m

wavFile = 'S:\path\to\2716_CallType_1A.wav';   % set to your local copy

[wav, fs] = audioread(wavFile);
wav = wav - mean(wav);

bpFilt = fir1(100, [50 250]/(fs/2), 'bandpass');

[pulse, unit] = prrTwoScale(wav, fs, bpFilt);

fprintf('PULSE scale:\n');
fprintf('  ACF rate:   %.3f Hz  (period %.3f s)  isTonal=%d\n', ...
    pulse.acfRate, 1/pulse.acfRate, pulse.acfIsTonal);
fprintf('  Welch rate: %.3f Hz\n', pulse.welchRate);
fprintf('  agree:      %d\n\n', pulse.agree);

fprintf('UNIT scale:\n');
fprintf('  ACF rate:   %.4f Hz  (%.2f s)\n', unit.acfRate, 1/unit.acfRate);
fprintf('  Welch rate: %.4f Hz  (%.2f s)\n', unit.welchRate, 1/unit.welchRate);
fprintf('  agree:      %d\n', unit.agree);

figure;
tl = tiledlayout(2,2);
title(tl, {'Bioduck pulse-rate vs unit-rate: ACF vs Welch compared', ...
    '(spectrogram-based cepstrum tested separately - no comb detected at either scale, see header)'});

nexttile;
plot(pulse.acfLags, pulse.acf); hold on;
xline(1/pulse.acfRate, 'r--', sprintf('%.3f Hz (ACF)', pulse.acfRate));
xlabel('lag (s)'); ylabel('autocorrelation'); title('Pulse scale: ACF');
xlim([0 1]);

nexttile;
plot(pulse.welchF, pulse.welchPower); hold on;
xline(pulse.welchRate, 'b--', sprintf('%.3f Hz (Welch)', pulse.welchRate));
xline(pulse.acfRate, 'r:', sprintf('%.3f Hz (ACF, for reference)', pulse.acfRate));
xlabel('Hz'); ylabel('PSD'); title('Pulse scale: Welch PSD');
xlim([0 12]);

nexttile;
plot(unit.acfLags, unit.acf); hold on;
xline(1/unit.welchRate, 'b--', sprintf('%.2f s (Welch)', 1/unit.welchRate));
xline(1/unit.acfRate, 'r--', sprintf('%.2f s (ACF)', 1/unit.acfRate));
xlabel('lag (s)'); ylabel('autocorrelation'); title('Unit scale: ACF');
xlim([0 20]);

nexttile;
plot(unit.welchF, unit.welchPower); hold on;
xline(unit.welchRate, 'b--', sprintf('%.3f Hz (Welch)', unit.welchRate));
xline(unit.acfRate, 'r:', sprintf('%.3f Hz (ACF, for reference)', unit.acfRate));
xlabel('Hz'); ylabel('PSD'); title('Unit scale: Welch PSD');
xlim([0 1]);
