"""
demo_two_scale_bioduck.py

Pulse-rate and unit-rate estimation on a real bioduck recording, using
prr_two_scale from prr_analysis.py.

Terminology: pulse (single downsweep) -> unit (sub-train of pulses) ->
call (the full sequence).

Validated result on 2716_CallType_1A.wav (176 s):
    pulse rate: ACF 2.632 Hz, Welch 5.469 Hz (2:1 harmonic, ACF correct)
    unit rate:  ACF 12.80 s (~4x harmonic), Welch 3.20 s (Welch correct,
                matches Dreo et al. 2025's published AMW ICI range of
                2.7-3.3 s)

Usage:
    python demo_two_scale_bioduck.py /path/to/2716_CallType_1A.wav
"""

import sys
import numpy as np
import soundfile as sf
from scipy.signal import firwin
from prr_analysis import prr_two_scale, cepstrum_via_spectrogram


def main(wav_path):
    wav, fs = sf.read(wav_path)
    wav = wav - wav.mean()

    bp = firwin(101, [50, 250], pass_zero=False, fs=fs)

    pulse, unit = prr_two_scale(wav, fs, bp)

    print('PULSE scale:')
    print(f'  ACF rate:   {pulse.acf_rate:.3f} Hz  (period {1/pulse.acf_rate:.3f} s)  '
          f'isTonal={pulse.acf_is_tonal}')
    print(f'  Welch rate: {pulse.welch_rate:.3f} Hz')
    print(f'  agree:      {pulse.agree}')
    print()
    print('UNIT scale:')
    print(f'  ACF rate:   {unit.acf_rate:.4f} Hz  ({1/unit.acf_rate:.2f} s)')
    print(f'  Welch rate: {unit.welch_rate:.4f} Hz  ({1/unit.welch_rate:.2f} s)')
    print(f'  agree:      {unit.agree}')

    # Cepstrum via the real spectrogram-based method (matching
    # cepstroBSM.m). Included for completeness / transparency: this does
    # NOT show usable comb structure on bioduck at these parameters -- see
    # cepstrum_via_spectrogram's docstring for the working hypothesis why
    # (wideband chirp vs the narrowband-tone assumption the method relies
    # on). Reported here rather than silently dropped.
    cepP, qP = cepstrum_via_spectrogram(wav, fs, 50, 250, 400, 1024, 0.75)
    cepU, qU = cepstrum_via_spectrogram(wav, fs, 50, 250, 400, 8000, 0.75)
    idxP = (qP > 0.02) & (qP < 1.0)
    idxU = (qU > 0.5) & (qU < 10.0)
    print()
    print('CEPSTRUM (spectrogram-based, cepstroBSM.m-style) - diagnostic only:')
    print(f'  pulse-band global max in [0.02,1.0]s: {qP[idxP][np.argmax(cepP[idxP])]:.3f} s'
          f'  (expected 0.380 s -- NOT where the max is; no comb detected)')
    print(f'  unit-band global max in [0.5,10]s:    {qU[idxU][np.argmax(cepU[idxU])]:.3f} s'
          f'  (expected 3.20 s -- NOT where the max is; no comb detected)')

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        fig, axs = plt.subplots(2, 2, figsize=(12, 7))

        axs[0, 0].plot(pulse.acf_lags, pulse.acf)
        axs[0, 0].axvline(1/pulse.acf_rate, color='r', ls='--',
                           label=f'{pulse.acf_rate:.3f} Hz (ACF)')
        axs[0, 0].set_xlim(0, 1)
        axs[0, 0].set_xlabel('lag (s)'); axs[0, 0].set_ylabel('autocorrelation')
        axs[0, 0].set_title('Pulse scale: ACF'); axs[0, 0].legend(fontsize=8)

        axs[0, 1].plot(pulse.welch_f, pulse.welch_power)
        axs[0, 1].axvline(pulse.welch_rate, color='b', ls='--',
                           label=f'{pulse.welch_rate:.3f} Hz (Welch)')
        axs[0, 1].axvline(pulse.acf_rate, color='r', ls=':',
                           label=f'{pulse.acf_rate:.3f} Hz (ACF, for reference)')
        axs[0, 1].set_xlim(0, 12)
        axs[0, 1].set_xlabel('Hz'); axs[0, 1].set_ylabel('PSD')
        axs[0, 1].set_title('Pulse scale: Welch PSD'); axs[0, 1].legend(fontsize=8)

        axs[1, 0].plot(unit.acf_lags, unit.acf)
        axs[1, 0].axvline(1/unit.welch_rate, color='b', ls='--',
                           label=f'{1/unit.welch_rate:.2f} s (Welch)')
        axs[1, 0].axvline(1/unit.acf_rate, color='r', ls='--',
                           label=f'{1/unit.acf_rate:.2f} s (ACF)')
        axs[1, 0].set_xlim(0, 20)
        axs[1, 0].set_xlabel('lag (s)'); axs[1, 0].set_ylabel('autocorrelation')
        axs[1, 0].set_title('Unit scale: ACF'); axs[1, 0].legend(fontsize=8)

        axs[1, 1].plot(unit.welch_f, unit.welch_power)
        axs[1, 1].axvline(unit.welch_rate, color='b', ls='--',
                           label=f'{unit.welch_rate:.3f} Hz (Welch)')
        axs[1, 1].axvline(unit.acf_rate, color='r', ls=':',
                           label=f'{unit.acf_rate:.3f} Hz (ACF, for reference)')
        axs[1, 1].set_xlim(0, 1)
        axs[1, 1].set_xlabel('Hz'); axs[1, 1].set_ylabel('PSD')
        axs[1, 1].set_title('Unit scale: Welch PSD'); axs[1, 1].legend(fontsize=8)

        fig.suptitle('Bioduck pulse-rate vs unit-rate: ACF vs Welch compared\n'
                      '(spectrogram-based cepstrum tested separately -- no comb '
                      'detected at either scale, see console output)',
                      fontsize=10)
        plt.tight_layout()
        outpath = 'two_scale_demo.png'
        plt.savefig(outpath, dpi=130)
        print(f'\nSaved plot to {outpath}')
    except ImportError:
        pass

    return pulse, unit


if __name__ == '__main__':
    wav_path = sys.argv[1] if len(sys.argv) > 1 else '2716_CallType_1A.wav'
    main(wav_path)
