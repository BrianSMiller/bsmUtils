function [prrMax, isTonal, acf, lags] = prrAutocorr(wav, sampleRate, bpFilt, outputRate, envCutoffHz, searchBandHz, peakProminence)
% PRRAUTOCORR  Estimate pulse repetition rate via envelope autocorrelation.
%
% Implements the method of:
%   Patris, J., Malige, F., Glotin, H., Asch, M., and Buchan, S.J. (2019).
%   "A standardized method of classifying pulsed sounds and its application
%   to pulse rate measurement of blue whale southeast Pacific song units,"
%   J. Acoust. Soc. Am. 146(4), 2145-2154.
%
% Companion to prr.m (Klink 2008 tEST, Welch PSD peak-pick). Instead of
% picking the peak of the envelope's power spectrum, this finds PRR from
% the TALLEST genuine local maximum (findpeaks, not a raw global max) of
% the envelope's autocorrelation function within searchBandHz.
%
% Patris et al.'s stated procedure (Sec. II C.1, step 5) is to take the
% FIRST maximum of the autocorrelation function, not the tallest. Testing
% against a real bioduck recording showed literal first-peak selection is
% fragile: a weak local bump well before the true dominant peak (lag
% 0.19 s, ACF~0.10, next to the true period at lag 0.38 s, ACF~0.68) got
% selected instead of the real period, because it technically qualifies
% as "first". This function deliberately deviates from the paper's
% literal wording and takes the tallest local maximum instead, which is
% far more robust to this kind of secondary structure on real,
% non-idealized recordings.
%
% Using findpeaks rather than a raw max() still matters, for a different
% reason: a raw global max within the search band can land on the
% boundary point nearest lag 0 if that boundary falls inside the broad
% decay tail of the zero-lag correlation hump, rather than on a real
% periodic peak. This is not a corner case - it produced a spurious exact
% prrMax at the search band's own edge frequency during development, on
% the same bioduck recording's slow (sub-train / "unit"-scale)
% periodicity. findpeaks with peakProminence avoids that by requiring an
% actual local maximum.
%
% Even with proper local-peak detection restricted to the tallest
% candidate, autocorrelation can still miss a real periodicity if it's too
% small to rise above a decay trend that hasn't settled by the true
% period's lag (observed on the same file's unit scale: Welch PSD
% correctly found 3.20 s, but the ACF's tallest genuine local max was a
% further-out ripple at 6.60 s). That is a real limit of this method on
% that signal, not something peak-selection logic alone fixes. See
% prrWelch.m and prrTwoScale.m, and always sanity-check prrMax against the
% acf plot rather than trusting the number alone.
%
% Patris et al. report this method substantially more precise than FFT
% peak-difference methods for short signals (~1.5% vs ~8% relative
% uncertainty in their test case), because autocorrelation resolution
% isn't limited by FFT bin width (1/Tsignal).
%
% Tonality (Patris et al. Sec. II A) is computed as a diagnostic, not a
% gate: it tells you whether autocorrelation is theoretically unbiased for
% this signal, but prrMax is still returned either way. Treat prrMax as
% potentially biased when isTonal is false or NaN.
%
% NOTE: Patris et al. describe a further refinement for tonal signals,
% "summed autocorrelation" of the raw (unenvelope) signal (citing Wise et
% al. 1976), which they report as their most precise method (~0.3% error
% in their test case). The paper does not give the algorithm in enough
% detail to reimplement faithfully, so it is NOT included here. This
% function implements only the envelope-autocorrelation method, which the
% paper itself validates as a solid middle ground (~1.5% error).
%
% Example - synthetic tonal pulse train, fpulse = 6 Hz
%     [wav, fs] = synthPulseTrain(6, 31.7, 4, 48000, 'A');
%     bpFilt = fir1(8, [5 200]/(fs/2), 'bandpass');
%     [prrMax, isTonal] = prrAutocorr(wav, fs, bpFilt, 1000, 10, [2 20]);
%
% Inputs
%   wav            acoustic signal, single channel
%   sampleRate     sample rate of wav, Hz
%   bpFilt         FIR bandpass coefficients (as from fir1), applied via filter()
%   outputRate     decimated envelope sample rate, Hz (as in prr.m)
%   envCutoffHz    lowpass cutoff for envelope smoothing, Hz (Patris et al. used 10 Hz)
%   searchBandHz   [minHz maxHz], range of candidate PRR values to search
%   peakProminence minimum findpeaks prominence, normalized ACF units
%                  [-1,1] (default 0.02; retune for lower-SNR recordings)
%
% Outputs
%   prrMax   estimated pulse repetition rate, Hz
%   isTonal  diagnostic tonality flag from checkTonal.m; NaN if too few
%            spectral peaks were found to test
%   acf      autocorrelation function of the envelope, positive lags only
%   lags     lag axis for acf, in seconds

if nargin < 7 || isempty(peakProminence)
    peakProminence = 0.02;
end

showPlot = nargout == 0;

% Mean-remove the raw waveform first (matches project convention
% x = x - mean(x)). Also makes the result independent of whether the
% caller already did this: found during validation that leaving a raw DC
% offset in vs removing it beforehand was enough to flip which of two
% close-in-height unit-scale ACF candidate peaks won the tallest-peak
% selection below, a real run-to-run inconsistency, not a rounding
% curiosity.
wav = double(wav(:));
wav = wav - mean(wav);

x = filter(bpFilt, 1, wav);

[env, envRate] = envelopeExtract(x, sampleRate, envCutoffHz, outputRate);
env = env - mean(env);

[acfFull, lagSamples] = xcorr(env, 'coeff');
posIx = lagSamples >= 0;
acf = acfFull(posIx);
lags = lagSamples(posIx) / envRate;

minLag = 1 / searchBandHz(2);
maxLag = 1 / searchBandHz(1);
searchIx = lags >= minLag & lags <= maxLag;

if ~any(searchIx)
    error('prrAutocorr:emptySearchRange', ...
        'No lags fall within searchBandHz [%g %g]. Check outputRate and searchBandHz.', ...
        searchBandHz(1), searchBandHz(2));
end

acfSearch = acf(searchIx);
lagsSearch = lags(searchIx);

[pkVals, pkLocs] = findpeaks(acfSearch, 'MinPeakProminence', peakProminence);
if isempty(pkLocs)
    error('prrAutocorr:noLocalMax', ...
        ['No genuine local maximum found within searchBandHz [%g %g] ' ...
         '(peakProminence=%g). The signal may not be periodic in this ' ...
         'band, or peakProminence may need lowering.'], ...
        searchBandHz(1), searchBandHz(2), peakProminence);
end
[~, tallestIx] = max(pkVals);
peakIx = pkLocs(tallestIx);
prrMax = 1 / lagsSearch(peakIx);

% Diagnostic tonality check: FFT peaks of the bandpassed signal vs prrMax
nfftDiag = 2^nextpow2(length(x));
X = abs(fft(x, nfftDiag));
fDiag = (0:nfftDiag-1) * (sampleRate/nfftDiag);
halfN = floor(nfftDiag/2);

minPeakDistSamples = max(1, round(0.5 * prrMax * nfftDiag / sampleRate));
[~, pkLocs] = findpeaks(X(1:halfN), 'MinPeakDistance', minPeakDistSamples, ...
    'MinPeakHeight', 0.1*max(X(1:halfN)));
peakFreqs = fDiag(pkLocs);

if numel(peakFreqs) >= 2
    isTonal = checkTonal(peakFreqs, prrMax, 0.1);
else
    isTonal = NaN;
    warning('prrAutocorr:tonalCheckSkipped', ...
        'Fewer than 2 spectral peaks found for tonality check; isTonal set to NaN.');
end

if showPlot
    subplot(2,1,1);
    plot((0:length(env)-1)/envRate, env);
    xlabel('time (s)'); ylabel('envelope (mean-removed)');
    subplot(2,1,2);
    plot(lags, acf); hold on;
    plot(lagsSearch(peakIx), acfSearch(peakIx), 'ro');
    xlabel('lag (s)'); ylabel('autocorrelation');
    title(sprintf('prrMax = %.3f Hz, isTonal = %d', prrMax, isTonal));
    drawnow;
end
